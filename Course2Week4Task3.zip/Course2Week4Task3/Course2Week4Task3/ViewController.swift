//
//  ViewController.swift
//  Course2Week4Task3
//
//  Created by Mykhailo Romanovskyi on 11.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var launchTime: UILabel!
    @IBOutlet weak var appearanceTime: UILabel!
    @IBOutlet weak var upDate: UIBarButtonItem!
    
   override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        launchTime.text = getCurrentDate()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        appearanceTime.text = getCurrentDate()
    }
    
    @IBAction func update(_ sender: Any) {
         appearanceTime.text = getCurrentDate()
    }
    
    func getCurrentDate() -> String {
        let rightnow = Date()
        let dateFormater = DateFormatter()
        dateFormater.dateStyle = .medium
        dateFormater.timeStyle = .medium
        return dateFormater.string(from: rightnow)
    }
}

