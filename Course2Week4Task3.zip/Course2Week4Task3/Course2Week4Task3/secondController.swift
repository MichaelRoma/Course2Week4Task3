//
//  secondController.swift
//  Course2Week4Task3
//
//  Created by Mykhailo Romanovskyi on 11.02.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import Foundation
import UIKit

class secondView: UIViewController {
    
    override var prefersStatusBarHidden: Bool {
          return true
      }
}
